(function (window) {
  var krilloudSDK = {};
  var globalPath;
  var relativePath;
  var isMainLoopInit;

  class Queue {
    constructor() {
      this.runningExec = false;
      this.queueList = [];
      this.isEmpty = null;
    }

    isRunnigExec() {
      return this.runningExec;
    }

    addRequest(request) {
      this.queueList.push(request);
      return this.queueList;
    }

    async executeList() {
      this.runningExec = true;
      var firstElement = this.queueList.shift();
      const unboundAction = firstElement.action;
      const boundAction = unboundAction.bind(firstElement);

      await boundAction();

      if (this.queueList.length > 0) {
        this.executeList();
      } else {
        this.runningExec = false;
      }
    }
  }

  var queue = new Queue();

  krilloudSDK.isEnabled = function () {
    console.log("krilloudSDK enabled");
  };

  
  krilloudSDK.start = async function (contractPath, soundBankPath) {
    globalPath = contractPath;
    relativePath = soundBankPath;
    /* await new Promise((resolve, reject) => {
      let id = setTimeout(() => {
        clearTimeout(id);
        resolve('Timed out in '+ 2000 + 'ms.')
      }, 2000)
    }) */
    return new Promise((resolve, reject) => {
      js_wrapped_EX_Krilloud_Create(
        globalPath,
        relativePath
      ).then((result) => {
        js_wrapped_EX_Krilloud_Init(1, 0, 0, 0, 2).then((result) => {
          resolve(result);
        });
      });
    });
  };

  krilloudSDK.load = async function (tagsToLoad) {
    const module = {
      tags: tagsToLoad,
      relativePathWeb: relativePath,
      action: function () {
        return new Promise(async (resolve, reject) => {
          for (var i = 0; i < this.tags.length; i++) {
            let tagToLoad = this.tags[i];
            await js_wrapped_EX_Krilloud_Load(
              tagToLoad.names,
              tagToLoad.names.split(",").length,
              tagToLoad.objectId,
              this.relativePathWeb
            );
          }
          await mainLoop();
          resolve(0);
        });
      },
    };
    manageRequest(module);
  };

  krilloudSDK.play = function (tagName, objectId) {
    const module = {
      tagName: tagName,
      objectId: objectId,
      action: function () {
        return js_wrapped_EX_Krilloud_Play(this.tagName, this.objectId);
      },
    };
    manageRequest(module);
  };

  krilloudSDK.stopTag = async function (tagName, objectId) {
    const module = {
      tagName: tagName,
      objectId: objectId,
      action: function () {
        return js_wrapped_EX_Krilloud_StopTag(this.tagName, this.objectId);
      },
    };
    manageRequest(module);
  };

  krilloudSDK.setVar = function (tagVar, objectId, value) {
    const module = {
      tagVar: tagVar,
      objectId: objectId,
      value: value,
      action: function () {
        if (Number.isInteger(value)) {
          return js_wrapped_EX_Krilloud_UpdateKVar_INT(
            this.tagVar,
            this.objectId,
            this.value
          );
        } else {
          return js_wrapped_EX_Krilloud_UpdateKVar_FLOAT(
            this.tagVar,
            this.objectId,
            this.value
          );
        }
      },
    };
    manageRequest(module);
  };

  async function manageRequest(request) {
    queue.addRequest(request);
    if (!queue.isRunnigExec()) {
      queue.executeList();
    }
  }

  async function mainLoop() {
    if (!isMainLoopInit) {
      await js_wrapped_EX_Krilloud_MainLoop();
      isMainLoopInit = true;
    }
  }

  async function cancelMainLoop() {
    if (isMainLoopInit) {
      await js_wrapped_EX_Krill_Cancel_MainLoop();
      isMainLoopInit = false;
    }
  }
  window.krilloudSDK = krilloudSDK;
})(window, undefined);
